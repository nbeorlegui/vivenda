export interface AlquilerPorVencer {
  nombre: string;
  domicilio: string;
  inicio: string;
  fin: string;
}
