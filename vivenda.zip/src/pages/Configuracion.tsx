const Configuracion = () => {
  return <div className="p-8">⚙️ Página de Configuración</div>;
};

export default Configuracion;
