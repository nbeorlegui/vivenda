const Clientes = () => {
  return <div className="p-8">👥 Página de Clientes</div>;
};

export default Clientes;
