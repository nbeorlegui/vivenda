const Alertas = () => {
  return <div className="p-8">🔔 Página de Alertas</div>;
};

export default Alertas;
